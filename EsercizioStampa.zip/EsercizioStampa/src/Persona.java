public class Persona extends Thread{

    private String nome;
    private Stampante stampante;
    private Semaforo semaforo;

    public Persona(String nome, Stampante stampante, Semaforo semaforo){

        this.nome = nome;
        this.stampante = stampante;
        this.semaforo = semaforo;
    }

    public String getNome() {
        return nome;
    }

    public Stampante getStampante() {
        return stampante;
    }

    public Semaforo getSemaforo() {
        return semaforo;
    }

    @Override
    public void run(){
        int randomSec = (int)(Math.random() * 5) +1; 
        
        try {
            Thread.sleep(randomSec * 1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        int randomNum = (int)(Math.random() * 3) +1;  

        
        semaforo.P();
        
        stampante.stampa(nome, randomNum);
        System.out.println(" FINITO: " + nome );
        
        semaforo.V();
    }
}