public class Stampante {

    private String nome;

    public Stampante(String nome){

        this.nome = nome;

    }

    public void stampa(String nome, int n){

        for(int i = 0; i<n; i++){

            System.out.println("----------------");
            System.out.println("|              |");
            System.out.println("|              |");
            System.out.println("|"+ nome +"|");
            System.out.println("|              |");
            System.out.println("|              |");
            System.out.println("| Stampa foglio" + i + "|");
            System.out.println("|              |");
            System.out.println("|              |");
            System.out.println("----------------");
            
        }
    }
    
}
