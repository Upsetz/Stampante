public class App {
    public static void main(String[] args) throws Exception {
        
        Stampante s = new Stampante("S1");
        Semaforo semaforo = new Semaforo(1);

        Persona p1 = new Persona("Samu", s , semaforo);
        Persona p2 = new Persona("Gabbri", s , semaforo);
        Persona p3 = new Persona("Andre", s , semaforo);
        Persona p4 = new Persona("Giova", s , semaforo);
        Persona p5 = new Persona("rida", s , semaforo);

        p1.start();
        p2.start();
        p3.start();
        p4.start();
        p5.start();

        p1.join();
        p2.join();
        p3.join();
        p4.join();
        p5.join();


    }
}
